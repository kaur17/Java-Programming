/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */
public class StringTools {

     ////////////reverse(String s) : String/////////////
    
    
   public static String reverseString(String s) {
        
        char[] array = new char[s.length()];
        for (int i = 0; i < array.length; i++) 
        {
            array[i] = s.charAt(s.length() - i - 1);
        }
        
        return new String(array);
        
    }
   
   public static String initials(String s){
       
     String name = new String();
       if( name == "J.T.Kirk")
       {
           System.out.println(name);
       }
      
 
       return null;
    
   
   }
   
   public static String mostFrequents(String s){
       
//       char[] c = new char[s.];
      
       
       
       
       
       return null; 
   }
   
   
   
   
   public static String replaceSubStrings(String s1, String s2, String s3)
   {
      //String str = String.replaceAll("","","");
    
       
       
     
       
       
       
       
       
       return null;
    
   }
   
   
   
 
    public static void main(String[] args) {

        String original = "Welcome";
        String reversed = reverseString(original);
        System.out.println(original);
        System.out.println(reversed);
      
        String N1 = "James tiBeriUs kiRK";
        String Name = initials(N1);
        System.out.println(Name);
        String N2 = "jean luc picard";
        //System.out.println(N2);
       
        

    }
    
    
   
    
    
    

}
