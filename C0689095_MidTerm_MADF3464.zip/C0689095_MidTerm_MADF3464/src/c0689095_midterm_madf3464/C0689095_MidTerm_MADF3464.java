/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c0689095_midterm_madf3464;

public class C0689095_MidTerm_MADF3464 {

   
    public static void main(String[] args) {
        
           String[][] cardList = { 
                            {"A","4","3"},
                            {"K","7","2"},
                            {"5","9","8"} 
                             };   

for (int i = 0; i < cardList.length; i++) {
    for (int j = 0; j < cardList[i].length; j++) {
        System.out.print(cardList[i][j] + " ");
    }
    System.out.println();
}

    }
    
 
   public static void shuffle(String s){
                
  
        }
}

    






  

    
       
  
        
        
   
  


 
  
